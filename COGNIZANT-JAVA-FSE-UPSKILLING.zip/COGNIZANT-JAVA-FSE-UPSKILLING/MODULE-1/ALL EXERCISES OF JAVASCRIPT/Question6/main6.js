// Initialize empty array for community events
const communityEvents = [];

// Add new events using .push()
communityEvents.push({ name: "Baking Workshop", category: "Music" });
communityEvents.push({ name: "Guitar Lessons", category: "Music" });
communityEvents.push({ name: "Art Exhibition", category: "Art" });
communityEvents.push({ name: "Dance Party", category: "Music" });
communityEvents.push({ name: "Book Club", category: "Literature" });

// Use .filter() to show only music events
const musicEvents = communityEvents.filter(event => event.category === "Music");

// Use .map() to create display cards (strings)
const displayCards = musicEvents.map(event => `${event.name} on Music`);

// Display results in console
console.log("All Community Events:", communityEvents);
console.log("Filtered Music Events:", musicEvents);
console.log("Display Cards for Music Events:");
displayCards.forEach(card => console.log(card));
