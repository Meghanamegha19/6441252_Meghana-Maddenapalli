// Array to store events
const events = [];

// Function to add a new event
function addEvent(name, date, seats, category) {
    events.push({ name, date, seats, category, registrations: 0 });
}

// Closure to track total registrations by category
function createRegistrationTracker(category) {
    let totalRegistrations = 0;

    return function register(event) {
        if (event.category === category) {
            if (event.seats > 0) {
                event.seats--;
                event.registrations++;
                totalRegistrations++;
                console.log(`Registered for ${event.name} (${category}). Seats left: ${event.seats}`);
            } else {
                console.log(`No seats left for ${event.name} (${category})`);
            }
        }
        return totalRegistrations;
    };
}

// Higher-order function to filter events dynamically using a callback
function filterEventsByCategory(filterCallback) {
    return events.filter(filterCallback);
}

// Adding some events
addEvent("Community Meetup", "2025-06-15", 10, "Social");
addEvent("Tech Talk", "2025-07-10", 5, "Tech");
addEvent("Workshop", "2025-08-01", 0, "Tech");
addEvent("Music Festival", "2025-09-12", 20, "Entertainment");

// Create registration tracker for Tech events
const registerTechEvent = createRegistrationTracker("Tech");

// Filter tech events with seats available
const techEventsAvailable = filterEventsByCategory(event => event.category === "Tech" && event.seats > 0);

console.log("Tech Events with available seats:");
techEventsAvailable.forEach(event => {
    console.log(`- ${event.name} (${event.seats} seats)`);
});

// Register users for tech events and track total registrations
let totalTechRegs = 0;
techEventsAvailable.forEach(event => {
    totalTechRegs = registerTechEvent(event);
});

console.log(`Total registrations in Tech category: ${totalTechRegs}`);
