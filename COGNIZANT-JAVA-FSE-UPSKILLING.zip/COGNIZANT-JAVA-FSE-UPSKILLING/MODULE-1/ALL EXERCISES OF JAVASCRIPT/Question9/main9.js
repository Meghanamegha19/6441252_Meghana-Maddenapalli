const eventsContainer = document.querySelector("#events-container");
const loading = document.querySelector("#loading");
const fetchThenBtn = document.querySelector("#fetchThen");
const fetchAsyncBtn = document.querySelector("#fetchAsync");

// Mock API URL - Using a JSON placeholder for demonstration
const mockAPI = "https://jsonplaceholder.typicode.com/posts?_limit=5";

// Helper function to display events
function displayEvents(events) {
  eventsContainer.innerHTML = "";
  events.forEach(event => {
    const div = document.createElement("div");
    div.className = "event";
    div.textContent = `Event: ${event.title}`;
    eventsContainer.appendChild(div);
  });
}

// Fetch events using .then() and .catch()
function fetchEventsThen() {
  loading.style.display = "block";
  eventsContainer.innerHTML = "";
  fetch(mockAPI)
    .then(response => {
      if (!response.ok) throw new Error("Network error");
      return response.json();
    })
    .then(data => {
      displayEvents(data);
      loading.style.display = "none";
    })
    .catch(error => {
      loading.style.display = "none";
      eventsContainer.textContent = "Error loading events: " + error.message;
    });
}

// Fetch events using async/await
async function fetchEventsAsync() {
  try {
    loading.style.display = "block";
    eventsContainer.innerHTML = "";
    const response = await fetch(mockAPI);
    if (!response.ok) throw new Error("Network error");
    const data = await response.json();
    displayEvents(data);
  } catch (error) {
    eventsContainer.textContent = "Error loading events: " + error.message;
  } finally {
    loading.style.display = "none";
  }
}

// Event listeners for buttons
fetchThenBtn.onclick = fetchEventsThen;
fetchAsyncBtn.onclick = fetchEventsAsync;

