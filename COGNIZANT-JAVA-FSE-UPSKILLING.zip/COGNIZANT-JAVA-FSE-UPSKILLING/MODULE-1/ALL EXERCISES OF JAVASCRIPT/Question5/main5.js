// Define Event class
class Event {
    constructor(name, date, seats) {
        this.name = name;
        this.date = date;
        this.seats = seats;
    }
}

// Add checkAvailability() method to Event prototype
Event.prototype.checkAvailability = function() {
    return this.seats > 0;
};

// Create some event objects
const event1 = new Event("Community Meetup", "2025-06-15", 10);
const event2 = new Event("Tech Talk", "2025-07-20", 0);

// Function to list keys and values of an object
function listKeysAndValues(obj) {
    const entries = Object.entries(obj);
    console.log(`Listing properties for event: ${obj.name}`);
    entries.forEach(([key, value]) => {
        console.log(`${key}: ${value}`);
    });
    console.log('---');
}

// Check availability and list keys & values for each event
[event1, event2].forEach(event => {
    console.log(`${event.name} availability: ${event.checkAvailability() ? "Seats available" : "Full"}`);
    listKeysAndValues(event);
});
