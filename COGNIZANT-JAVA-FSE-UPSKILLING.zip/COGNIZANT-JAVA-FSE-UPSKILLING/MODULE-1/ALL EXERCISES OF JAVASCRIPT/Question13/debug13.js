const form = document.querySelector("#debugForm");
const status = document.querySelector("#status");

form.addEventListener("submit", function (event) {
  event.preventDefault();
  console.log("Form submitted"); // ✅ Step 1: log submission

  const formData = new FormData(form);
  const userData = {
    name: formData.get("name"),
    email: formData.get("email"),
    event: formData.get("event"),
  };

  console.log("Captured user data:", userData); // ✅ Step 2: inspect data
  status.textContent = "Registering...";

  // 🔍 Add a breakpoint on the next line to inspect userData
  setTimeout(() => {
    fetch("https://jsonplaceholder.typicode.com/posts", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(userData),
    })
      .then((response) => {
        console.log("Fetch response status:", response.status); // ✅ Step 3: check response
        return response.json();
      })
      .then((json) => {
        console.log("Response JSON:", json); // ✅ Step 4: inspect returned data
        status.textContent = `✅ Registered successfully for ${json.event}`;
        form.reset();
      })
      .catch((error) => {
        console.error("Error occurred:", error); // ✅ Step 5: catch error
        status.textContent = "❌ Registration failed.";
      });
  }, 2000);
});
