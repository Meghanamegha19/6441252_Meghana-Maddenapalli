const eventName = "Community Meetup";
const eventDate = "2025-06-15";
let availableSeats = 50;

console.log(`Event: ${eventName}`);
console.log(`Date: ${eventDate}`);
console.log(`Seats Available: ${availableSeats}`);

availableSeats--;  // One seat taken
console.log(`Seats Available after registration: ${availableSeats}`);

availableSeats++;  // One seat freed
console.log(`Seats Available after cancellation: ${availableSeats}`);
