const form = document.querySelector("#registerForm");
const result = document.querySelector("#result");

form.addEventListener("submit", function (event) {
  event.preventDefault(); // Stop page reload

  const formData = new FormData(form);
  const data = {
    name: formData.get("name"),
    email: formData.get("email"),
    event: formData.get("event"),
  };

  result.textContent = "Sending registration...";

  // Simulate delay with setTimeout
  setTimeout(() => {
    fetch("https://jsonplaceholder.typicode.com/posts", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error("Server error");
        }
        return response.json();
      })
      .then((json) => {
        result.textContent = `✅ Registered successfully! Name: ${json.name}, Event: ${json.event}`;
        form.reset();
      })
      .catch((error) => {
        result.textContent = "❌ Registration failed: " + error.message;
      });
  }, 2000); // 2-second delay
});
