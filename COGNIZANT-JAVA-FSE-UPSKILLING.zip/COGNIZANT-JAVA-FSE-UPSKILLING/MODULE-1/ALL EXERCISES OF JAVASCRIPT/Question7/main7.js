// Sample event data
const events = [
    { id: 1, name: "Community Meetup", seats: 5 },
    { id: 2, name: "Tech Talk", seats: 0 },
    { id: 3, name: "Workshop", seats: 3 },
];

// Select container where events will be shown
const eventsContainer = document.querySelector("#events-container");

// Function to render all events on the page
function renderEvents() {
    // Clear current content
    eventsContainer.innerHTML = "";

    events.forEach(event => {
        // Create card div
        const card = document.createElement("div");
        card.className = "event-card";

        // Event name and seats info
        const info = document.createElement("p");
        info.textContent = `${event.name} — Seats available: ${event.seats}`;
        card.appendChild(info);

        // Register button
        const registerBtn = document.createElement("button");
        registerBtn.textContent = "Register";
        registerBtn.className = "btn";
        registerBtn.disabled = event.seats === 0;
        registerBtn.addEventListener("click", () => {
            if (event.seats > 0) {
                event.seats--;
                renderEvents();  // Update UI
            }
        });
        card.appendChild(registerBtn);

        // Cancel button
        const cancelBtn = document.createElement("button");
        cancelBtn.textContent = "Cancel";
        cancelBtn.className = "btn";
        cancelBtn.disabled = event.seats === 5;  // assuming max seats 5 here
        cancelBtn.addEventListener("click", () => {
            if (event.seats < 5) {
                event.seats++;
                renderEvents();  // Update UI
            }
        });
        card.appendChild(cancelBtn);

        // Add card to container
        eventsContainer.appendChild(card);
    });
}

// Initial render
renderEvents();
