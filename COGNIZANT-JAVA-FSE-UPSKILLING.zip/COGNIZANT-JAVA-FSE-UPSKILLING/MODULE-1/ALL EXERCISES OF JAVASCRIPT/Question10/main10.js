// Original list of events
const originalEvents = [
  { id: 1, name: "Community Meetup", category: "Tech", seats: 5 },
  { id: 2, name: "Music Festival", category: "Music", seats: 0 },
  { id: 3, name: "Art Workshop", category: "Art", seats: 10 },
];

// Function with default parameter
const filterEvents = (events = [], category = "All") => {
  // Clone events array using spread operator
  const eventsCopy = [...events];

  // Filter events by category if not 'All'
  return category === "All"
    ? eventsCopy
    : eventsCopy.filter(({ category: cat }) => cat === category);
};

// Function to display event info
const displayEvents = (events) => {
  const container = document.querySelector("#events-output");
  container.innerHTML = ""; // clear previous output

  events.forEach(event => {
    // Destructure event details
    const { name, category, seats } = event;
    const eventInfo = document.createElement("p");
    eventInfo.textContent = `${name} (${category}) - Seats: ${seats}`;
    container.appendChild(eventInfo);
  });
};

// Usage examples
const allEvents = filterEvents(originalEvents);
const musicEvents = filterEvents(originalEvents, "Music");

displayEvents(allEvents);

// After 3 seconds, show only Music events
setTimeout(() => {
  displayEvents(musicEvents);
}, 3000);
