// List of events - each event is an object with name, date, and available seats
const events = [
    { name: "Community Meetup", date: "2025-06-15", seats: 10 },
    { name: "Tech Talk", date: "2023-12-01", seats: 0 },           // past or full event
    { name: "Workshop", date: "2025-07-20", seats: 5 },
    { name: "Hackathon", date: "2024-01-10", seats: 0 },           // full event
];

// Function to check if an event is upcoming (date is in future)
function isUpcoming(eventDate) {
    const today = new Date();
    const eventDay = new Date(eventDate);
    return eventDay >= today;
}

// Display only valid events
console.log("Valid Upcoming Events with Available Seats:");
events.forEach(event => {
    if (isUpcoming(event.date) && event.seats > 0) {
        console.log(`- ${event.name} on ${event.date} | Seats: ${event.seats}`);
    }
});

// Registration logic wrapped in try-catch
function register(event) {
    try {
        if (!isUpcoming(event.date)) {
            throw new Error("Cannot register: Event is in the past.");
        }
        if (event.seats <= 0) {
            throw new Error("Cannot register: No seats available.");
        }
        // Registration success: reduce seats by 1
        event.seats--;
        console.log(`Registration successful for ${event.name}. Seats left: ${event.seats}`);
    } catch (error) {
        console.error(`Error: ${error.message}`);
    }
}

// Test registration for each event
events.forEach(event => {
    console.log(`Trying to register for: ${event.name}`);
    register(event);
});
