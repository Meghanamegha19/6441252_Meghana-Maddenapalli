$(document).ready(function () {
  // Handle Register button click
  $('#registerBtn').click(function () {
    $('.event-card').fadeIn();
  });

  // Handle Cancel button click
  $('#cancelBtn').click(function () {
    $('.event-card').fadeOut();
  });
});
