const events = [
    { id: 1, name: "Baking Workshop", category: "Music", seats: 5 },
    { id: 2, name: "Guitar Lessons", category: "Music", seats: 3 },
    { id: 3, name: "Tech Talk", category: "Tech", seats: 4 },
    { id: 4, name: "Art Exhibition", category: "Art", seats: 2 },
    { id: 5, name: "Dance Party", category: "Music", seats: 0 },
];

// Get DOM elements
const eventsContainer = document.querySelector("#events-container");
const categoryFilter = document.querySelector("#categoryFilter");
const searchInput = document.querySelector("#searchInput");

// Render events based on filters
function renderEvents() {
    eventsContainer.innerHTML = "";

    // Get current filter and search
    const selectedCategory = categoryFilter.value;
    const searchText = searchInput.value.toLowerCase();

    // Filter events by category and search text
    const filteredEvents = events.filter(event => {
        const matchCategory = selectedCategory === "All" || event.category === selectedCategory;
        const matchName = event.name.toLowerCase().includes(searchText);
        return matchCategory && matchName;
    });

    // Show filtered events
    filteredEvents.forEach(event => {
        const card = document.createElement("div");
        card.className = "event-card";

        const info = document.createElement("p");
        info.textContent = `${event.name} (${event.category}) - Seats: ${event.seats}`;
        card.appendChild(info);

        const registerBtn = document.createElement("button");
        registerBtn.textContent = "Register";
        registerBtn.className = "btn";
        registerBtn.disabled = event.seats === 0;
        // onclick event for register
        registerBtn.onclick = function() {
            if (event.seats > 0) {
                event.seats--;
                renderEvents();  // update UI
            }
        };
        card.appendChild(registerBtn);

        eventsContainer.appendChild(card);
    });

    if(filteredEvents.length === 0) {
        eventsContainer.textContent = "No events found.";
    }
}

// Event listener for category filter onchange
categoryFilter.onchange = renderEvents;

// Event listener for search input keydown (trigger search on every key press)
searchInput.onkeydown = function(event) {
    // Slight delay to allow input value update
    setTimeout(renderEvents, 0);
};

// Initial render
renderEvents();
