const form = document.querySelector("#registrationForm");
const nameInput = form.elements["name"];
const emailInput = form.elements["email"];
const eventSelect = form.elements["eventSelect"];

const nameError = document.querySelector("#nameError");
const emailError = document.querySelector("#emailError");
const eventError = document.querySelector("#eventError");
const successMessage = document.querySelector("#successMessage");

form.addEventListener("submit", function(event) {
  event.preventDefault(); // prevent default form submission

  // Clear previous errors and success message
  nameError.textContent = "";
  emailError.textContent = "";
  eventError.textContent = "";
  successMessage.textContent = "";

  let valid = true;

  // Validate Name: not empty
  if (!nameInput.value.trim()) {
    nameError.textContent = "Please enter your name.";
    valid = false;
  }

  // Validate Email: simple check for "@" presence
  if (!emailInput.value.trim()) {
    emailError.textContent = "Please enter your email.";
    valid = false;
  } else if (!emailInput.value.includes("@")) {
    emailError.textContent = "Please enter a valid email.";
    valid = false;
  }

  // Validate Event selection: must not be empty
  if (!eventSelect.value) {
    eventError.textContent = "Please select an event.";
    valid = false;
  }

  // If all inputs valid, show success message
  if (valid) {
    successMessage.textContent = `Thank you, ${nameInput.value}! You registered for "${eventSelect.value}".`;

    // Optionally reset form
    form.reset();
  }
});
