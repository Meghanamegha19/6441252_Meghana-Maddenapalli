import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
public class FileWritingExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a string to write to the file: ");
        String userInput = scanner.nextLine();
        try {
            // Create a FileWriter to write to output.txt
            FileWriter writer = new FileWriter("output.txt");
            // Write the user input to the file
            writer.write(userInput);
            // Close the FileWriter
            writer.close();
            // Confirm the data has been written
            System.out.println("Data has been written to output.txt");
        } catch (IOException e) { //If writing to the file fails, this catch block shows a message and prints error details.
            // Handle file writing errors
            System.out.println("An error occurred while writing to the file.");
            e.printStackTrace();
        }
        scanner.close();
    }
}

