public class PatternMatchingSwitch {
    
    // Method that accepts any object
    public static void checkType(Object obj) {
        // Pattern matching with enhanced switch
        switch (obj) {
            case Integer i -> System.out.println("It is an Integer: " + i);
            case String s -> System.out.println("It is a String: " + s);
            case Double d -> System.out.println("It is a Double: " + d);
            case null -> System.out.println("It is null.");
            default -> System.out.println("Unknown type: " + obj); // For all other types (like Boolean), prints a generic message.
        }
    }

    public static void main(String[] args) {
        checkType(42);              // Integer
        checkType("Hello");         // String
        checkType(3.14);            // Double
        checkType(true);            // Unknown type
        checkType(null);            // Null
    }
}
