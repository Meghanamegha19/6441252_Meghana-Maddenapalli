import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
public class FileReadingExample {
    public static void main(String[] args) {
        try {
            // Step 1: Open the file
            File file = new File("output.txt");
            Scanner reader = new Scanner(file);
            // Step 2: Read and display each line
            System.out.println("Contents of output.txt:");
            while (reader.hasNextLine()) {
                String line = reader.nextLine();  // Read a line
                System.out.println(line);         // Print the line
            }
            // Step 3: Close the reader
            reader.close();
        } catch (FileNotFoundException e) {
            // If file not found, show an error message
            System.out.println("The file output.txt was not found.");
        }
    }
}

