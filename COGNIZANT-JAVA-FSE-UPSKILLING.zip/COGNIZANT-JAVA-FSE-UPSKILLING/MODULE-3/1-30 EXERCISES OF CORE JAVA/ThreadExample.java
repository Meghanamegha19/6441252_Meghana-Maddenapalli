// Define a class that implements Runnable
class MessagePrinter implements Runnable {
    private String message;

    // Constructor to set message for each thread
    public MessagePrinter(String message) {
        this.message = message;
    }

    // Code that runs in the thread
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println(message + " - Count: " + i);
        }
    }
}
// problem Thread creation
public class ThreadExample {
    public static void main(String[] args) {
        // Create two Runnable objects with different messages
        MessagePrinter printer1 = new MessagePrinter("Hello from Thread 1");
        MessagePrinter printer2 = new MessagePrinter("Hello from Thread 2");

        // Create Thread objects and pass the Runnable objects
        Thread thread1 = new Thread(printer1);
        Thread thread2 = new Thread(printer2);

        // Start both threads
        thread1.start();
        thread2.start();
    }
}
