import java.util.Scanner;
import java.util.Random;
public class NumberGuessingGame {
    public static void main(String[] args) {
        Random random = new Random(); //Random is used to generate a random number between 1 and 100
        Scanner scanner = new Scanner(System.in);
        int numberToGuess = random.nextInt(100) + 1; //random.nextInt(100) generates a random number from 0 to 99.Adding +1 makes the number go from 1 to 100 (instead of 0 to 99).
        int userGuess = 0; //It sets the starting value to 0.
        System.out.println("Guess the number between 1 and 100:");
        while (userGuess != numberToGuess) { //"Keep looping as long as the user's guess is not equal to the secret number."
            System.out.print("Enter your guess: ");
            userGuess = scanner.nextInt();
            if (userGuess < numberToGuess) {
                System.out.println("Too low! Try again.");
            } else if (userGuess > numberToGuess) {
                System.out.println("Too high! Try again.");
            } else {
                System.out.println("Congratulations! You guessed the correct number.");
            }
        }
        scanner.close(); 
    }
}
