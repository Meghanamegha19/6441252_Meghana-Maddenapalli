import java.util.*;
import java.util.stream.Collectors; //Needed to collect the filtered results into a new list.

public class StreamEvenNumbers {
    public static void main(String[] args) {
        // Create a list of integers
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);

        // Use Stream API to filter even numbers and collect them
        List<Integer> evenNumbers = numbers.stream()
                                           .filter(n -> n % 2 == 0)
                                           .collect(Collectors.toList());

        // Display the result
        System.out.println("Even numbers: " + evenNumbers);
    }
}
// .stream() → Converts the list into a stream for processing.

// .filter(n -> n % 2 == 0) → Keeps only even numbers (n % 2 == 0).

// .collect(Collectors.toList()) → Collects the filtered numbers into a new list.

