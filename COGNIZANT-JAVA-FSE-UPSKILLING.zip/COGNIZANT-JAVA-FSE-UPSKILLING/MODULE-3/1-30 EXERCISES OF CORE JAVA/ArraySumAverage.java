import java.util.Scanner;
public class ArraySumAverage {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);       
        System.out.print("Enter the number of elements: ");
        int n = scanner.nextInt();
        // Create an array to hold the numbers.create an integer array called numbers that can store n elements.
        int[] numbers = new int[n];
        // user enter the numbers one by one.
        System.out.println("Enter " + n + " numbers:");
        for (int i = 0; i < n; i++) { //position
            numbers[i] = scanner.nextInt();  
        }
        int sum = 0;
        // Calculate the sum of all elements
        for (int i = 0; i < n; i++) {
            sum += numbers[i];  
        }
        // Calculate the average
        double average = (double) sum / n;
        System.out.println("Sum = " + sum);
        System.out.println("Average = " + average);
        scanner.close();
    }
}
