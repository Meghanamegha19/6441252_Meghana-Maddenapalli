import java.util.ArrayList;
import java.util.Scanner;
public class StudentList { //ArrayList
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        // Step 1: Create an ArrayList to store student names
        ArrayList<String> students = new ArrayList<>();
        // Step 2: Ask the user how many names they want to enter
        System.out.print("How many student names do you want to enter? ");
        int count = scanner.nextInt();
        scanner.nextLine(); // Clear the newline character
        // Step 3: Take names as input and add to the list
        for (int i = 0; i < count; i++) {
            System.out.print("Enter student name #" + (i + 1) + ": ");
            String name = scanner.nextLine();
            students.add(name); 
        }
        // Step 4: Display all names entered
        System.out.println("\nList of Student Names:");
        for (String name : students) {
            System.out.println(name);
        }
        scanner.close(); 
    }
}
