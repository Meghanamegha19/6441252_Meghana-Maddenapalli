import java.util.Scanner;
public class StringReversal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String input = scanner.nextLine();
        //StringBuilder to reverse the string
        StringBuilder reversed = new StringBuilder(input);
        reversed.reverse(); // Reverse the characters
        System.out.println("Reversed string: " + reversed);
        scanner.close();
    }
}
