public class OperatorPrecedence {
    public static void main(String[] args) {
        // Example expression
        int result1 = 10 + 5 * 2;
        int result2 = (10 + 5) * 2;

        // Display the results
        System.out.println("Result1 (10 + 5 * 2): " + result1);
        System.out.println("Result2 ((10 + 5) * 2): " + result2);
    }
}
//1.	() Parentheses	(2 + 3) * 4	  
//2.	*, /, %     	 4 * 5 / 2	  
//3.	+, -	        10 + 2 - 5	 

