import java.util.Scanner;
public class FactorialCalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a non-negative integer: ");
        int number = scanner.nextInt();
        // Variable to store the factorial result
        long factorial = 1; //= 1 means we start with the value 1 because when multiplying, starting with 1 won’t change the result.
        if (number < 0) {
            System.out.println("Factorial is not defined for negative numbers.");
        } else {
            for (int i = 1; i <= number; i++) {
                factorial = factorial * i;
            }
            System.out.println("Factorial of " + number + " is: " + factorial);
        }
        scanner.close();
    }
}
//number=4
//Step 1: factorial = 1 * 1 → 1

//Step 2: factorial = 1 * 2 → 2

//Step 3: factorial = 2 * 3 → 6

//Step 4: factorial = 6 * 4 → 24 