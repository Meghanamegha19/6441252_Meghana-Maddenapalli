public class DataTypeDemo {
    public static void main(String[] args) {
        int myInt=19;
        float myFloat=11.9f;
        double myDouble=62.8181;
        char myChar='M';
        boolean myBoolean=true;
         System.out.println("Integer value: " + myInt);
        System.out.println("Float value: " + myFloat);
        System.out.println("Double value: " + myDouble);
        System.out.println("Character value: " + myChar);
        System.out.println("Boolean value: " + myBoolean);
    }
}
