// Define the Car class
class Car {
    // Attributes
    String make;
    String model;
    int year;
    // Method to display car details
    void displayDetails() {
        System.out.println("Make: " + make);
        System.out.println("Model: " + model);
        System.out.println("Year: " + year);
    }
}
// Main class to run the program
public class CarExample {
    public static void main(String[] args) {
        // Create first car object
        Car car1 = new Car();
        car1.make = "Toyota";
        car1.model = "Corolla";
        car1.year = 2020;
        car1.displayDetails();
        System.out.println(); // Line break
        // Create second car object
        Car car2 = new Car();
        car2.make = "Honda";
        car2.model = "Civic";
        car2.year = 2022;
        car2.displayDetails();
    }
}
