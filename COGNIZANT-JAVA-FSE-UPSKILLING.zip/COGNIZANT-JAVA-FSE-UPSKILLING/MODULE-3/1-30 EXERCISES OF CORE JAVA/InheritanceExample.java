// Base class
class Animal {
    // Method in Animal class
    void makeSound() {
        System.out.println("Animal makes a sound");
    }
}
// Subclass Dog inherits from Animal
class Dog extends Animal {
    // Overriding makeSound() method
    @Override
    void makeSound() {
        System.out.println("Bark");
    }
}
// Main class to test
public class InheritanceExample {
    public static void main(String[] args) {
        // Create an object of Animal
        Animal animal = new Animal();
        animal.makeSound();  // Calls Animal's makeSound()
        // Create an object of Dog
        Dog dog = new Dog();
        dog.makeSound();     // Calls Dog's overridden makeSound()
    }
}
