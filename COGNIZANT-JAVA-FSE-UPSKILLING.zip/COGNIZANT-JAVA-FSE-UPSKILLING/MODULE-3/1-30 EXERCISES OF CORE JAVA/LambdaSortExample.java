import java.util.*;

public class LambdaSortExample {
    public static void main(String[] args) {
        // Create a list of strings
        List<String> names = new ArrayList<>();
        names.add("Zara"); //names.add(...) → Adds names to the list.
        names.add("Alex");
        names.add("Mohan");
        names.add("Bina");

        // Collections.sort(...) -->Sort the list using a lambda expression
        //(a, b) -> a.compareTo(b) means: compare two names and sort them in alphabetical order.
        Collections.sort(names, (a, b) -> a.compareTo(b));

        // Display the sorted list
        System.out.println("Sorted names:");
        for (String name : names) { //for (String name : names) → Loops through and prints each name.
            System.out.println(name);
        }
    }
}
