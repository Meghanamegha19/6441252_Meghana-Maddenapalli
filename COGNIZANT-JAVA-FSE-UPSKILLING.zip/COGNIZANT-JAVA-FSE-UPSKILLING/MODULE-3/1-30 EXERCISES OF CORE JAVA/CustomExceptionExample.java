import java.util.Scanner;

// Step 1: Create a custom exception class
class InvalidAgeException extends Exception { // This line defines a custom exception class called InvalidAgeException. It inherits from Java’s built-in Exception
    public InvalidAgeException(String message) { //constructor of the InvalidAgeException.
        super(message); //passes this message to the base Exception class, so it can be displayed later.
    }
}

public class CustomExceptionExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Step 2: Ask the user for age
        System.out.print("Enter your age: ");
        int age = scanner.nextInt();

        try {
            // Step 3: Check if age is less than 18
            if (age < 18) {
                // Step 4: Throw custom exception
                throw new InvalidAgeException("You must be at least 18 years old.");
            } else {
                System.out.println("You are eligible!");
            }
        } catch (InvalidAgeException e) {
            // Step 5: Catch and handle custom exception
            System.out.println("InvalidAgeException: " + e.getMessage());
        }

        scanner.close();
    }
}

