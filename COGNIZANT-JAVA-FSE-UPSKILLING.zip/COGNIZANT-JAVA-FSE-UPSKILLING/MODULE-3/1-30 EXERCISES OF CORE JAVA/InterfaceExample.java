// Define an interface
interface Playable {
    void play();  // Method to be implemented
}
// Implementing the interface in Guitar class
class Guitar implements Playable {
    public void play() {
        System.out.println("Playing the guitar");
    }
}
// Implementing the interface in Piano class
class Piano implements Playable {
    public void play() { //public-The method can be accessed from outside the class — this is required to match the interface method.
        System.out.println("Playing the piano");
    }
}
// Main class
public class InterfaceExample {
    public static void main(String[] args) {
        // Create objects of Guitar and Piano
        Playable guitar = new Guitar();
        Playable piano = new Piano();
        // Call play() method
        guitar.play(); // Output: Playing the guitar
        piano.play();  // Output: Playing the piano
    }
}
