public class TypeCastingExample {
    public static void main(String[] args) {
        double myDouble=9.73;
        int myInt=(int) myDouble; //Bigger type → smaller type = you must say it yourself
        System.out.println("Original double value: " + myDouble);
        System.out.println("After casting to int: " + myInt);
        int number=19;
        double convertedDouble=number; //Small number → bigger type = automatic 
        System.out.println("Original int value: " + number);
        System.out.println("After casting to double: " + convertedDouble);
    }
}
