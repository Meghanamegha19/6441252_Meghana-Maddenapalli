import java.util.HashMap;
import java.util.Scanner;
public class StudentMap {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Create a HashMap with Integer keys (student IDs) and String values (names)
        HashMap<Integer, String> studentMap = new HashMap<>();

        // Prompt user to add entries
        System.out.print("How many students do you want to add? ");
        int count = scanner.nextInt();
        scanner.nextLine(); // Consume the newline

        // Get student ID and name from the user
        for (int i = 0; i < count; i++) {
            System.out.print("Enter student ID: ");
            int id = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            System.out.print("Enter student name: ");
            String name = scanner.nextLine();
            studentMap.put(id, name); // Add ID-name pair to HashMap
        }

        // Prompt user to enter an ID to look up a student name
        System.out.print("Enter a student ID to find the name: ");
        int searchId = scanner.nextInt();

        // Retrieve and display the name based on the entered ID
        if (studentMap.containsKey(searchId)) { //containsKey(searchId) → checks if the student ID exists in the map.
            String studentName = studentMap.get(searchId); //get(searchId) → gets the name of the student for that ID.
            System.out.println("Student name: " + studentName);
        } else {
            System.out.println("No student found with ID: " + searchId);
        }
        scanner.close();
    }
}
