import java.util.*;
import java.util.stream.Collectors;

// Define a record named Person
record Person(String name, int age) {}

public class RecordExample {
    public static void main(String[] args) {
        // Create a list of Person records
        List<Person> people = List.of(
            new Person("Alice", 22),
            new Person("Bob", 17),
            new Person("Charlie", 25)
        );

        // Print all persons
        System.out.println("All people:");
        for (Person p : people) {
            System.out.println(p);
        }

        // Filter persons who are 18 or older
        List<Person> adults = people.stream()
                                    .filter(p -> p.age() >= 18)
                                    .collect(Collectors.toList());

        // Print filtered list
        System.out.println("\nAdults (18 or older):");
        for (Person p : adults) {
            System.out.println(p);
        }
    }
}
