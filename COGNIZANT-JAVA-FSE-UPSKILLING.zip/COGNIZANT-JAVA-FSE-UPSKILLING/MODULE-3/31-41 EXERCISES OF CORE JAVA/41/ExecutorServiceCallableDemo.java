import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*; // Import all necessary concurrency utilities

// A Callable task that performs a calculation and returns a result
class FactorialCalculator implements Callable<Long> {
    private int number;

    public FactorialCalculator(int number) {
        this.number = number;
    }

    @Override
    public Long call() throws Exception {
        if (number < 0) {
            throw new IllegalArgumentException("Number must be non-negative");
        }
        if (number == 0 || number == 1) {
            return 1L;
        }

        long result = 1;
        for (int i = 2; i <= number; i++) {
            result *= i;
            // Simulate some work or delay
            Thread.sleep(50);
        }
        System.out.println("Calculated factorial of " + number + " by " + Thread.currentThread().getName());
        return result;
    }
}

public class ExecutorServiceCallableDemo {

    private static final int NUM_TASKS = 5; // Number of factorial tasks
    private static final int THREAD_POOL_SIZE = 2; // Number of threads in the pool

    public static void main(String[] args) {
        System.out.println("Demonstrating ExecutorService with Callable tasks.\n");

        // Step 1: Create an ExecutorService with a fixed-size thread pool.
        // This pool will reuse a fixed number of threads to execute tasks.
        ExecutorService executorService = Executors.newFixedThreadPool(THREAD_POOL_SIZE);
        System.out.println("ExecutorService created with " + THREAD_POOL_SIZE + " threads.");

        // List to hold Future objects, which will eventually hold the results of our Callable tasks.
        List<Future<Long>> futures = new ArrayList<>();

        // Step 2: Submit Callable tasks to the ExecutorService.
        // Each task is submitted, and a Future object is returned immediately.
        for (int i = 1; i <= NUM_TASKS; i++) {
            // We'll calculate factorial for numbers 5, 6, 7, 8, 9
            int numberToCalculate = 4 + i;
            FactorialCalculator task = new FactorialCalculator(numberToCalculate);
            System.out.println("Submitting task for factorial of " + numberToCalculate + "...");
            Future<Long> future = executorService.submit(task);
            futures.add(future);
        }

        // Step 3: Collect results using Future.get().
        // Future.get() is a blocking call; it waits until the task completes and returns its result.
        System.out.println("\n--- Collecting Results ---");
        for (int i = 0; i < futures.size(); i++) {
            Future<Long> future = futures.get(i);
            try {
                // The get() method will block until the result is available.
                // You can also use get(timeout, unit) to wait for a limited time.
                Long result = future.get(); // This line blocks
                System.out.println("Result for task " + (i + 1) + ": " + result);
            } catch (InterruptedException e) {
                System.err.println("Task was interrupted: " + e.getMessage());
                Thread.currentThread().interrupt(); // Restore the interrupted status
            } catch (ExecutionException e) {
                // This exception is thrown if the Callable task itself throws an exception.
                System.err.println("Task execution failed for task " + (i + 1) + ": " + e.getCause().getMessage());
            }
        }

        // Step 4: Shut down the ExecutorService.
        // This prevents new tasks from being submitted and waits for previously submitted
        // tasks to complete.
        executorService.shutdown();
        System.out.println("\nExecutorService shutdown initiated.");

        // Optional: Wait for all tasks to terminate gracefully.
        try {
            if (!executorService.awaitTermination(60, TimeUnit.SECONDS)) {
                // If tasks don't complete within the timeout, force shutdown.
                executorService.shutdownNow();
                System.err.println("ExecutorService did not terminate in time, forced shutdown.");
            } else {
                System.out.println("ExecutorService terminated gracefully.");
            }
        } catch (InterruptedException e) {
            System.err.println("Waiting for termination was interrupted.");
            executorService.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }
}
