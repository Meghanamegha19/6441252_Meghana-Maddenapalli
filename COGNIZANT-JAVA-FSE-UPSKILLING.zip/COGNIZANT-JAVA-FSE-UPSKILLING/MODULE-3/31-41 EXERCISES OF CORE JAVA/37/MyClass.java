public class MyClass {
    private int value;

    public MyClass(int value) {
        this.value = value;
    }

    public int add(int a, int b) {
        int sum = a + b;
        return sum * this.value;
    }

    public void printMessage(String message) {
        System.out.println("Message: " + message);
    }
}
