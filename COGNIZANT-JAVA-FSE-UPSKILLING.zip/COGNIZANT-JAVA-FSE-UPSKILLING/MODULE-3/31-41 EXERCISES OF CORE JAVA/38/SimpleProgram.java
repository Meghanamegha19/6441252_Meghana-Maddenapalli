public class SimpleProgram {

    public static void main(String[] args) {
        String greeting = getGreeting("World");
        System.out.println(greeting);
    }

    private static String getGreeting(String name) {
        String prefix = "Hello, ";
        return prefix + name + "!";
    }

    // A simple method that might be optimized by the compiler
    public int calculate(int x, int y) {
        int result = (x * 2) + y;
        if (result > 100) {
            return result - 50;
        } else {
            return result + 10;
        }
    }
}
