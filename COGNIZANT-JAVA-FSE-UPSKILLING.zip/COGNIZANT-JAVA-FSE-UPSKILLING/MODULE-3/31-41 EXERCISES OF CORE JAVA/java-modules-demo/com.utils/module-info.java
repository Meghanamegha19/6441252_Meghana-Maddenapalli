// Defines the com.utils module.
// It exports the com.utils package, making its public types accessible
// to other modules that require com.utils.
module com.utils {
    exports com.utils;
}