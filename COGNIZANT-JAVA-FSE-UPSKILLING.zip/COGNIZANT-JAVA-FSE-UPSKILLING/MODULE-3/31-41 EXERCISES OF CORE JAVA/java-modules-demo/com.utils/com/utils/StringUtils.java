package com.utils;

public class StringUtils {
    /**
     * Reverses a given string.
     * @param text The input string.
     * @return The reversed string.
     */
    public static String reverse(String text) {
        if (text == null || text.isEmpty()) {
            return text;
        }
        return new StringBuilder(text).reverse().toString();
    }

    /**
     * Converts the first letter of a string to uppercase.
     * @param text The input string.
     * @return The string with the first letter capitalized.
     */
    public static String capitalizeFirstLetter(String text) {
        if (text == null || text.isEmpty()) {
            return text;
        }
        return Character.toUpperCase(text.charAt(0)) + text.substring(1);
    }
}