package com.greetings;

// Import the utility class from the com.utils module
import com.utils.StringUtils;

public class Main {
    public static void main(String[] args) {
        String original = "hello modules";
        String reversed = StringUtils.reverse(original);
        String capitalized = StringUtils.capitalizeFirstLetter(original);

        System.out.println("Original: " + original);
        System.out.println("Reversed: " + reversed);
        System.out.println("Capitalized: " + capitalized);

        System.out.println("\nGreetings from the 'com.greetings' module!");
    }
}
