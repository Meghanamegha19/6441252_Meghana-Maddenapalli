// Defines the com.greetings module.
// It requires the com.utils module, meaning it can use types
// exported by com.utils.
module com.greetings {
    requires com.utils;
}