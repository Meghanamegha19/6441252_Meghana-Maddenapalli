import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcTransactionHandling {

    private static final String JDBC_URL = "jdbc:sqlite:bank.db";

    public static void main(String[] args) {
        // Load JDBC driver
        try {
            Class.forName("org.sqlite.JDBC");
            System.out.println("SQLite JDBC Driver loaded.");
        } catch (ClassNotFoundException e) {
            System.err.println("Error loading SQLite JDBC Driver: " + e.getMessage());
            return;
        }

        // Initialize database and accounts
        initializeDatabase();

        // Perform a successful transfer
        System.out.println("\n--- Attempting Successful Transfer ---");
        transferMoney(1, 2, 50.0); // Transfer $50 from Account 1 to Account 2
        displayAccountBalances();

        // Perform a transfer that should fail (insufficient funds)
        System.out.println("\n--- Attempting Failed Transfer (Insufficient Funds) ---");
        transferMoney(1, 2, 1000.0); // Transfer $1000 from Account 1 (initial balance 100)
        displayAccountBalances();

        // Perform a transfer to a non-existent account (should also rollback)
        System.out.println("\n--- Attempting Failed Transfer (Non-existent Account) ---");
        transferMoney(1, 99, 20.0); // Transfer $20 from Account 1 to Account 99
        displayAccountBalances();
    }

    /**
     * Initializes the database with an 'accounts' table and some initial data.
     */
    private static void initializeDatabase() {
        try (Connection connection = DriverManager.getConnection(JDBC_URL);
             Statement statement = connection.createStatement()) {

            // Create accounts table
            String createTableSQL = "CREATE TABLE IF NOT EXISTS accounts (" +
                                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                                    "name TEXT NOT NULL," +
                                    "balance REAL NOT NULL" +
                                    ");";
            statement.execute(createTableSQL);
            System.out.println("Table 'accounts' checked/created.");

            // Clear existing data and insert fresh data for consistent testing
            statement.executeUpdate("DELETE FROM accounts;");
            statement.executeUpdate("INSERT INTO accounts (id, name, balance) VALUES (1, 'Alice', 100.0);");
            statement.executeUpdate("INSERT INTO accounts (id, name, balance) VALUES (2, 'Bob', 150.0);");
            System.out.println("Initial account data inserted.");

        } catch (SQLException e) {
            System.err.println("Error initializing database: " + e.getMessage());
        }
    }

    /**
     * Transfers money between two accounts using JDBC transactions.
     * Ensures atomicity: either both debit and credit succeed, or neither does.
     *
     * @param fromAccountId The ID of the account to debit.
     * @param toAccountId   The ID of the account to credit.
     * @param amount        The amount of money to transfer.
     */
    public static void transferMoney(int fromAccountId, int toAccountId, double amount) {
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(JDBC_URL);
            // Step 1: Disable auto-commit mode. This means changes won't be saved
            // until commit() is called.
            connection.setAutoCommit(false);
            System.out.println("Auto-commit disabled.");

            // Step 2: Debit the sender's account
            String debitSQL = "UPDATE accounts SET balance = balance - ? WHERE id = ? AND balance >= ?;";
            try (PreparedStatement debitStmt = connection.prepareStatement(debitSQL)) {
                debitStmt.setDouble(1, amount);
                debitStmt.setInt(2, fromAccountId);
                debitStmt.setDouble(3, amount); // Ensure sufficient funds before debiting
                int affectedRows = debitStmt.executeUpdate();

                if (affectedRows == 0) {
                    // No rows affected means either account ID doesn't exist or insufficient funds
                    System.out.println("Transfer failed: Insufficient funds or sender account not found (ID: " + fromAccountId + ").");
                    connection.rollback(); // Rollback any partial changes
                    System.out.println("Transaction rolled back.");
                    return; // Exit method
                }
            }

            // Simulate a delay or potential error here if needed for testing rollback
            // if (fromAccountId == 1 && toAccountId == 99) {
            //     throw new SQLException("Simulated error during credit operation.");
            // }

            // Step 3: Credit the receiver's account
            String creditSQL = "UPDATE accounts SET balance = balance + ? WHERE id = ?;";
            try (PreparedStatement creditStmt = connection.prepareStatement(creditSQL)) {
                creditStmt.setDouble(1, amount);
                creditStmt.setInt(2, toAccountId);
                int affectedRows = creditStmt.executeUpdate();

                if (affectedRows == 0) {
                    // No rows affected means receiver account not found
                    System.out.println("Transfer failed: Receiver account not found (ID: " + toAccountId + ").");
                    connection.rollback(); // Rollback the debit
                    System.out.println("Transaction rolled back.");
                    return; // Exit method
                }
            }

            // Step 4: If both operations succeed, commit the transaction.
            connection.commit();
            System.out.printf("Transfer of %.2f from account %d to account %d successful.%n", amount, fromAccountId, toAccountId);

        } catch (SQLException e) {
            System.err.println("Transaction error: " + e.getMessage());
            if (connection != null) {
                try {
                    connection.rollback(); // Rollback on any SQL exception
                    System.out.println("Transaction rolled back due to error.");
                } catch (SQLException rollbackEx) {
                    System.err.println("Error during rollback: " + rollbackEx.getMessage());
                }
            }
        } finally {
            // Step 5: Always close the connection in the finally block.
            // Also, restore auto-commit mode if needed for subsequent operations (though not strictly necessary here).
            if (connection != null) {
                try {
                    connection.setAutoCommit(true); // Restore auto-commit
                    connection.close();
                } catch (SQLException e) {
                    System.err.println("Error closing connection: " + e.getMessage());
                }
            }
        }
    }

    /**
     * Displays the current balances of all accounts.
     */
    private static void displayAccountBalances() {
        System.out.println("\n--- Current Account Balances ---");
        String sql = "SELECT id, name, balance FROM accounts;";
        try (Connection connection = DriverManager.getConnection(JDBC_URL);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                double balance = resultSet.getDouble("balance");
                System.out.printf("Account ID: %d, Name: %s, Balance: %.2f%n", id, name, balance);
            }
        } catch (SQLException e) {
            System.err.println("Error displaying balances: " + e.getMessage());
        }
    }
}
