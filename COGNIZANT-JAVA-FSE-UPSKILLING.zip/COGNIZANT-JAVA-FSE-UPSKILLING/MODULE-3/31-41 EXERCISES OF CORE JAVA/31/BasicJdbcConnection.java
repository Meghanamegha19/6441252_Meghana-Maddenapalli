import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class BasicJdbcConnection {

    // JDBC URL for SQLite database. This will create a 'students.db' file
    // in the same directory where the program is run.
    private static final String JDBC_URL = "jdbc:sqlite:students.db";

    public static void main(String[] args) {
        // Step 1: Load the JDBC driver (for SQLite, this is usually done automatically
        // since Java 6, but explicitly calling it is good practice for older drivers).
        try {
            Class.forName("org.sqlite.JDBC");
            System.out.println("SQLite JDBC Driver loaded.");
        } catch (ClassNotFoundException e) {
            System.err.println("Error loading SQLite JDBC Driver: " + e.getMessage());
            return;
        }

        // Step 2: Establish a connection to the database.
        try (Connection connection = DriverManager.getConnection(JDBC_URL)) {
            System.out.println("Connection to SQLite database established.");

            // Step 3: Create a Statement object to execute SQL queries.
            Statement statement = connection.createStatement();

            // SQL to create the students table if it doesn't exist.
            String createTableSQL = "CREATE TABLE IF NOT EXISTS students (" +
                                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                                    "name TEXT NOT NULL," +
                                    "age INTEGER," +
                                    "grade TEXT" +
                                    ");";
            statement.execute(createTableSQL);
            System.out.println("Table 'students' checked/created.");

            // SQL to insert some sample data (only if table is empty or for demonstration).
            // Using INSERT OR IGNORE to avoid duplicate primary key errors if run multiple times.
            String insertDataSQL1 = "INSERT OR IGNORE INTO students (id, name, age, grade) VALUES (1, 'Alice', 20, 'A');";
            String insertDataSQL2 = "INSERT OR IGNORE INTO students (id, name, age, grade) VALUES (2, 'Bob', 22, 'B');";
            String insertDataSQL3 = "INSERT OR IGNORE INTO students (id, name, age, grade) VALUES (3, 'Charlie', 21, 'A');";
            statement.executeUpdate(insertDataSQL1);
            statement.executeUpdate(insertDataSQL2);
            statement.executeUpdate(insertDataSQL3);
            System.out.println("Sample data inserted (if not already present).");

            // Step 4: Execute a SELECT query to retrieve data.
            String selectSQL = "SELECT id, name, age, grade FROM students;";
            ResultSet resultSet = statement.executeQuery(selectSQL);
            System.out.println("\n--- Student Data ---");

            // Step 5: Process the ResultSet.
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                int age = resultSet.getInt("age");
                String grade = resultSet.getString("grade");
                System.out.printf("ID: %d, Name: %s, Age: %d, Grade: %s%n", id, name, age, grade);
            }

            // Close ResultSet and Statement (Connection is closed automatically by try-with-resources).
            resultSet.close();
            statement.close();

        } catch (SQLException e) {
            System.err.println("Database error: " + e.getMessage());
        }
    }
}
