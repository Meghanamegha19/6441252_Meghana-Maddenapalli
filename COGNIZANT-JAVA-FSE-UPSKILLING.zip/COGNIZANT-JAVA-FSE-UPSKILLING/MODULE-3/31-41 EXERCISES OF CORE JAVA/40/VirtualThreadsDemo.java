import java.time.Duration;
import java.time.Instant;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class VirtualThreadsDemo {

    private static final int NUM_THREADS = 100_000; // Number of threads to launch

    public static void main(String[] args) throws InterruptedException {
        System.out.println("Demonstrating Java Virtual Threads (requires Java 21+)\n");

        // --- Run with Virtual Threads ---
        System.out.println("Launching " + NUM_THREADS + " Virtual Threads...");
        Instant startVirtual = Instant.now();
        runWithVirtualThreads(NUM_THREADS);
        Instant endVirtual = Instant.now();
        System.out.println("Virtual Threads finished in: " + Duration.between(startVirtual, endVirtual).toMillis() + " ms");
        System.out.println("-------------------------------------\n");

        // --- Run with Traditional Platform Threads ---
        // WARNING: Launching 100,000 platform threads will likely cause OutOfMemoryError
        // or significant performance degradation on most systems.
        // Reducing NUM_THREADS for platform thread test to avoid crashing.
        int numPlatformThreads = 1000; // A more realistic number for platform threads
        System.out.println("Launching " + numPlatformThreads + " Traditional Platform Threads...");
        System.out.println("WARNING: This might be slow or cause OutOfMemoryError for large numbers.");
        Instant startPlatform = Instant.now();
        runWithPlatformThreads(numPlatformThreads);
        Instant endPlatform = Instant.now();
        System.out.println("Traditional Platform Threads finished in: " + Duration.between(startPlatform, endPlatform).toMillis() + " ms");
    }

    /**
     * Launches a specified number of virtual threads.
     * Each thread prints a message and sleeps briefly.
     *
     * @param count The number of virtual threads to launch.
     * @throws InterruptedException if the main thread is interrupted.
     */
    private static void runWithVirtualThreads(int count) throws InterruptedException {
        CountDownLatch latch = new CountDownLatch(count); // To wait for all threads to complete

        for (int i = 0; i < count; i++) {
            final int threadId = i;
            // Thread.startVirtualThread() is the simplest way to create and start a virtual thread
            Thread.startVirtualThread(() -> {
                // System.out.println("Virtual Thread " + threadId + " running."); // Uncomment for verbose output
                try {
                    Thread.sleep(1); // Simulate some non-CPU bound work
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                latch.countDown(); // Decrement latch when thread finishes
            });
        }
        latch.await(); // Wait for all virtual threads to complete
    }

    /**
     * Launches a specified number of traditional platform threads.
     * Each thread prints a message and sleeps briefly.
     *
     * @param count The number of platform threads to launch.
     * @throws InterruptedException if the main thread is interrupted.
     */
    private static void runWithPlatformThreads(int count) throws InterruptedException {
        CountDownLatch latch = new CountDownLatch(count); // To wait for all threads to complete

        // Using an ExecutorService for managing a large number of platform threads
        // is generally better than raw Thread creation, but for direct comparison,
        // we'll stick to raw Thread creation (which highlights the resource overhead).
        // For a more robust platform thread example, FixedThreadPool would be better.

        for (int i = 0; i < count; i++) {
            final int threadId = i;
            Thread platformThread = new Thread(() -> {
                // System.out.println("Platform Thread " + threadId + " running."); // Uncomment for verbose output
                try {
                    Thread.sleep(1); // Simulate some non-CPU bound work
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                latch.countDown(); // Decrement latch when thread finishes
            });
            platformThread.start();
        }
        latch.await(); // Wait for all platform threads to complete
    }
}
