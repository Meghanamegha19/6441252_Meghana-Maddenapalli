import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

// Student model class
class Student {
    private int id;
    private String name;
    private int age;
    private String grade;

    public Student(int id, String name, int age, String grade) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.grade = grade;
    }

    // Constructor for new students (ID will be auto-generated)
    public Student(String name, int age, String grade) {
        this.name = name;
        this.age = age;
        this.grade = grade;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }
    public String getGrade() { return grade; }
    public void setGrade(String grade) { this.grade = grade; }

    @Override
    public String toString() {
        return "Student [id=" + id + ", name=" + name + ", age=" + age + ", grade=" + grade + "]";
    }
}

// Data Access Object (DAO) for Student operations
class StudentDAO {
    private static final String JDBC_URL = "jdbc:sqlite:students.db";

    public StudentDAO() {
        // Ensure the table exists when DAO is initialized
        try (Connection connection = DriverManager.getConnection(JDBC_URL);
             Statement statement = connection.createStatement()) {
            String createTableSQL = "CREATE TABLE IF NOT EXISTS students (" +
                                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                                    "name TEXT NOT NULL," +
                                    "age INTEGER," +
                                    "grade TEXT" +
                                    ");";
            statement.execute(createTableSQL);
        } catch (SQLException e) {
            System.err.println("Error creating students table: " + e.getMessage());
        }
    }

    /**
     * Inserts a new student record into the database.
     * @param student The Student object to insert.
     * @return true if insertion was successful, false otherwise.
     */
    public boolean insertStudent(Student student) {
        String sql = "INSERT INTO students (name, age, grade) VALUES (?, ?, ?);";
        try (Connection connection = DriverManager.getConnection(JDBC_URL);
             PreparedStatement pstmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) { // RETURN_GENERATED_KEYS to get auto-incremented ID
            pstmt.setString(1, student.getName());
            pstmt.setInt(2, student.getAge());
            pstmt.setString(3, student.getGrade());

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                // Retrieve the auto-generated ID
                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        student.setId(generatedKeys.getInt(1)); // Set the ID back to the student object
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Error inserting student: " + e.getMessage());
        }
        return false;
    }

    /**
     * Updates an existing student record in the database.
     * @param student The Student object with updated details (ID must be set).
     * @return true if update was successful, false otherwise.
     */
    public boolean updateStudent(Student student) {
        String sql = "UPDATE students SET name = ?, age = ?, grade = ? WHERE id = ?;";
        try (Connection connection = DriverManager.getConnection(JDBC_URL);
             PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, student.getName());
            pstmt.setInt(2, student.getAge());
            pstmt.setString(3, student.getGrade());
            pstmt.setInt(4, student.getId()); // WHERE clause for the ID

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Error updating student: " + e.getMessage());
        }
        return false;
    }

    /**
     * Retrieves all students from the database.
     * @return A list of Student objects.
     */
    public void getAllStudents() {
        String sql = "SELECT id, name, age, grade FROM students;";
        try (Connection connection = DriverManager.getConnection(JDBC_URL);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {

            System.out.println("\n--- Current Student Data ---");
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                int age = resultSet.getInt("age");
                String grade = resultSet.getString("grade");
                System.out.printf("ID: %d, Name: %s, Age: %d, Grade: %s%n", id, name, age, grade);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving students: " + e.getMessage());
        }
    }
}

public class JdbcInsertUpdate {
    public static void main(String[] args) {
        // Load JDBC driver (same as before)
        try {
            Class.forName("org.sqlite.JDBC");
            System.out.println("SQLite JDBC Driver loaded.");
        } catch (ClassNotFoundException e) {
            System.err.println("Error loading SQLite JDBC Driver: " + e.getMessage());
            return;
        }

        StudentDAO studentDAO = new StudentDAO();

        // --- Insert Operations ---
        System.out.println("\n--- Performing Insert Operations ---");
        Student newStudent1 = new Student("David", 19, "C");
        if (studentDAO.insertStudent(newStudent1)) {
            System.out.println("Inserted: " + newStudent1);
        } else {
            System.out.println("Failed to insert: " + newStudent1.getName());
        }

        Student newStudent2 = new Student("Eve", 23, "A");
        if (studentDAO.insertStudent(newStudent2)) {
            System.out.println("Inserted: " + newStudent2);
        } else {
            System.out.println("Failed to insert: " + newStudent2.getName());
        }

        studentDAO.getAllStudents(); // Show all students after inserts

        // --- Update Operations ---
        System.out.println("\n--- Performing Update Operations ---");
        // Assuming David's ID is 4 (based on previous example's auto-increment, might vary)
        // It's better to use the ID returned by insertStudent if possible, but for demo,
        // we'll assume a known ID or fetch it. Here, we'll use the ID from newStudent1.
        if (newStudent1.getId() != 0) { // Check if ID was set after insertion
            newStudent1.setGrade("B+");
            newStudent1.setAge(20);
            if (studentDAO.updateStudent(newStudent1)) {
                System.out.println("Updated: " + newStudent1);
            } else {
                System.out.println("Failed to update: " + newStudent1.getName());
            }
        } else {
            System.out.println("Cannot update, newStudent1 ID not set.");
        }

        // Example of updating a student that might not exist or has a different ID
        Student studentToUpdate = new Student(2, "Bob", 23, "A+"); // Update Bob's details
        if (studentDAO.updateStudent(studentToUpdate)) {
            System.out.println("Updated: " + studentToUpdate);
        } else {
            System.out.println("Failed to update (ID might not exist): " + studentToUpdate.getName());
        }

        studentDAO.getAllStudents(); // Show all students after updates
    }
}
