import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;

// A sample class to demonstrate reflection on
class MyReflectableClass {
    private String name;

    public MyReflectableClass() {
        this.name = "Default";
    }

    public MyReflectableClass(String name) {
        this.name = name;
    }

    public void greet() {
        System.out.println("Hello from " + name + "!");
    }

    public String getInfo(int age, String city) {
        return name + " is " + age + " years old and lives in " + city + ".";
    }

    private void secretMethod() {
        System.out.println("This is a secret method!");
    }

    public static void staticMethod() {
        System.out.println("This is a static method.");
    }
}

public class ReflectionDemo {

    public static void main(String[] args) {
        String className = "MyReflectableClass"; // Class name as a String

        try {
            // Step 1: Load the class dynamically using Class.forName()
            Class<?> clazz = Class.forName(className);
            System.out.println("Class loaded: " + clazz.getName());

            // Step 2: Create an instance of the class (optional, needed for non-static method invocation)
            // Using the default constructor
            Object instance = clazz.getDeclaredConstructor().newInstance();
            // Or using a constructor with parameters:
            // Object instance = clazz.getDeclaredConstructor(String.class).newInstance("Reflected Object");
            System.out.println("Instance created: " + instance.getClass().getName());

            // Step 3: Get all declared methods of the class
            System.out.println("\n--- Declared Methods ---");
            Method[] methods = clazz.getDeclaredMethods(); // Includes public, private, protected, and default (but not inherited)

            for (Method method : methods) {
                System.out.println("Method Name: " + method.getName());
                System.out.println("  Return Type: " + method.getReturnType().getName());
                System.out.print("  Parameters: ");
                // Print parameter types
                Class<?>[] parameterTypes = method.getParameterTypes();
                if (parameterTypes.length == 0) {
                    System.out.println("None");
                } else {
                    Arrays.stream(parameterTypes)
                          .map(Class::getName)
                          .forEach(p -> System.out.print(p + " "));
                    System.out.println();
                }
                System.out.println("  Modifiers: " + java.lang.reflect.Modifier.toString(method.getModifiers()));
                System.out.println("---");
            }

            // Step 4: Invoke a specific method dynamically
            System.out.println("\n--- Dynamic Method Invocation ---");

            // Invoke 'greet' method (no parameters)
            try {
                Method greetMethod = clazz.getMethod("greet"); // getMethod() only returns public methods
                System.out.print("Invoking 'greet()': ");
                greetMethod.invoke(instance); // Pass the instance on which to invoke the method
            } catch (NoSuchMethodException e) {
                System.err.println("Method 'greet' not found: " + e.getMessage());
            }

            // Invoke 'getInfo' method (with parameters and return value)
            try {
                // getMethod takes method name and parameter types
                Method getInfoMethod = clazz.getMethod("getInfo", int.class, String.class);
                System.out.print("Invoking 'getInfo(25, \"New York\")': ");
                Object result = getInfoMethod.invoke(instance, 25, "New York"); // Pass instance and arguments
                System.out.println("Result: " + result);
            } catch (NoSuchMethodException e) {
                System.err.println("Method 'getInfo' not found: " + e.getMessage());
            }

            // Invoke a private method (requires setAccessible(true))
            try {
                Method secretMethod = clazz.getDeclaredMethod("secretMethod"); // getDeclaredMethod() gets non-public methods
                secretMethod.setAccessible(true); // Allow access to private method
                System.out.print("Invoking 'secretMethod()': ");
                secretMethod.invoke(instance);
            } catch (NoSuchMethodException e) {
                System.err.println("Method 'secretMethod' not found: " + e.getMessage());
            }

            // Invoke a static method
            try {
                Method staticMethod = clazz.getMethod("staticMethod");
                System.out.print("Invoking 'staticMethod()': ");
                staticMethod.invoke(null); // For static methods, instance can be null
            } catch (NoSuchMethodException e) {
                System.err.println("Method 'staticMethod' not found: " + e.getMessage());
            }


        } catch (ClassNotFoundException e) {
            System.err.println("Class not found: " + e.getMessage());
        } catch (InstantiationException | IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
            System.err.println("Error during reflection operation: " + e.getMessage());
            e.printStackTrace(); // Print full stack trace for detailed error
        }
    }
}
