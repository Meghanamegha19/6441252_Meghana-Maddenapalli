import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class ChatClient {
    private static final String SERVER_IP = "127.0.0.1"; // Server IP address (localhost)
    private static final int PORT = 12345; // Port number the server is listening on

    public static void main(String[] args) {
        System.out.println("Chat Client connecting to " + SERVER_IP + ":" + PORT + "...");
        try (Socket socket = new Socket(SERVER_IP, PORT)) {
            System.out.println("Connected to the chat server.");

            // Setup input and output streams for communication with the server
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true); // true for auto-flush

            Scanner scanner = new Scanner(System.in); // For client to send messages

            // Thread to read messages from the server
            Thread readThread = new Thread(() -> {
                String serverMessage;
                try {
                    while ((serverMessage = in.readLine()) != null) {
                        System.out.println("Server: " + serverMessage);
                        if (serverMessage.equalsIgnoreCase("bye")) {
                            System.out.println("Server said 'bye'. Closing connection.");
                            break; // Exit loop if server says bye
                        }
                    }
                } catch (IOException e) {
                    System.err.println("Error reading from server: " + e.getMessage());
                } finally {
                    try {
                        socket.close(); // Close socket when done
                    } catch (IOException e) {
                        System.err.println("Error closing socket: " + e.getMessage());
                    }
                }
            });
            readThread.start();

            // Main thread for client to send messages to the server
            String clientMessage;
            while (true) {
                System.out.print("Client (Type 'bye' to exit): ");
                clientMessage = scanner.nextLine();
                out.println(clientMessage); // Send message to server
                if (clientMessage.equalsIgnoreCase("bye")) {
                    System.out.println("Client said 'bye'. Exiting.");
                    break; // Exit loop if client says bye
                }
            }

            scanner.close();
            // The socket will be closed by its try-with-resources.
            // The readThread will handle closing its input stream.

        } catch (IOException e) {
            System.err.println("Client error: " + e.getMessage());
        }
    }
}
