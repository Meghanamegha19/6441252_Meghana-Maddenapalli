import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class ChatServer {
    private static final int PORT = 12345; // Port number for the server to listen on

    public static void main(String[] args) {
        System.out.println("Chat Server starting on port " + PORT + "...");
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Waiting for a client connection...");
            Socket clientSocket = serverSocket.accept(); // Blocks until a client connects
            System.out.println("Client connected: " + clientSocket.getInetAddress().getHostAddress());

            // Setup input and output streams for communication with the client
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true); // true for auto-flush

            Scanner scanner = new Scanner(System.in); // For server to send messages

            // Thread to read messages from the client
            Thread readThread = new Thread(() -> {
                String clientMessage;
                try {
                    while ((clientMessage = in.readLine()) != null) {
                        System.out.println("Client: " + clientMessage);
                        if (clientMessage.equalsIgnoreCase("bye")) {
                            System.out.println("Client said 'bye'. Closing connection.");
                            break; // Exit loop if client says bye
                        }
                    }
                } catch (IOException e) {
                    System.err.println("Error reading from client: " + e.getMessage());
                } finally {
                    try {
                        clientSocket.close(); // Close client socket when done
                    } catch (IOException e) {
                        System.err.println("Error closing client socket: " + e.getMessage());
                    }
                }
            });
            readThread.start();

            // Main thread for server to send messages to the client
            String serverMessage;
            while (true) {
                System.out.print("Server (Type 'bye' to exit): ");
                serverMessage = scanner.nextLine();
                out.println(serverMessage); // Send message to client
                if (serverMessage.equalsIgnoreCase("bye")) {
                    System.out.println("Server said 'bye'. Exiting.");
                    break; // Exit loop if server says bye
                }
            }

            scanner.close();
            // The clientSocket and serverSocket will be closed by their try-with-resources.
            // The readThread will handle closing its input stream.

        } catch (IOException e) {
            System.err.println("Server error: " + e.getMessage());
        }
    }
}
