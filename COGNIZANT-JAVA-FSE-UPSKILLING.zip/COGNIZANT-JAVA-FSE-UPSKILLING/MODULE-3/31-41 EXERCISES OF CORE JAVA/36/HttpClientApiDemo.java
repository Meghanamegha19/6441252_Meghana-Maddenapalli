import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

public class HttpClientApiDemo {

    public static void main(String[] args) {
        // Create an HttpClient instance.
        // Use newBuilder() to customize, or newHttpClient() for a default client.
        HttpClient client = HttpClient.newBuilder()
                .version(HttpClient.Version.HTTP_2) // Prefer HTTP/2 if available
                .followRedirects(HttpClient.Redirect.NORMAL) // Follow redirects
                .connectTimeout(Duration.ofSeconds(10)) // Set connection timeout
                .build();

        // Define the target URI for the public API.
        // Using GitHub's public API for a user profile.
        String apiUrl = "https://api.github.com/users/octocat";

        // Build an HttpRequest.
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(apiUrl)) // Set the URI
                .GET() // Specify the HTTP method (GET, POST, PUT, DELETE, etc.)
                .header("Accept", "application/json") // Request JSON response
                .timeout(Duration.ofSeconds(20)) // Set request timeout
                .build();

        System.out.println("Sending GET request to: " + apiUrl);

        try {
            // Send the request and receive the response.
            // HttpResponse.BodyHandlers.ofString() specifies that the response body
            // should be handled as a String.
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            // Print the response status code.
            System.out.println("\nResponse Status Code: " + response.statusCode());

            // Print the response headers (optional).
            // System.out.println("Response Headers: " + response.headers().map());

            // Print the response body.
            System.out.println("\nResponse Body:\n" + response.body());

            // Optional: Simple check for JSON content (without full parsing library)
            if (response.statusCode() == 200 && response.body().startsWith("{")) {
                System.out.println("\nResponse appears to be JSON.");
                // For robust JSON parsing, you would integrate libraries like Jackson or Gson:
                // ObjectMapper mapper = new ObjectMapper(); // Jackson
                // User user = mapper.readValue(response.body(), User.class);
                // System.out.println("Parsed User Login: " + user.getLogin());
            }

        } catch (IOException | InterruptedException e) {
            System.err.println("Error during HTTP request: " + e.getMessage());
            if (e instanceof InterruptedException) {
                Thread.currentThread().interrupt(); // Restore the interrupted status
            }
        }
    }
}
